import { Text, View, StyleSheet, TextInput, TouchableOpacity, ImageBackground} from 'react-native'
import React from 'react'
import axios from 'axios'
 
import * as Animatable from 'react-native-animatable'
import { useNavigation } from '@react-navigation/native'

export default function Signin() {
 
       
  const navigation = useNavigation();
 
  const callGetUsersList = () => {
       axios.get('https://crudcrud.com/api/4453925975e44e6ca49f93d94f22caf0/cadastro')
       .then(response => {
         navigation.navigate('Welcome');
       })
       .catch(error => {
         console.log("Error". error);
       });
     } 
 
    return (
      <View style={styles.container}>
      <ImageBackground source={require('../../assets/fundoapplogin.png')} resizeMode="cover" style={{width: '100%', height:'100%'}}>
        <Animatable.View animation='fadeInLeft' delay={500} style={styles.containerHeader}>
          <Text style={styles.message}>Welcome</Text>
        </Animatable.View>
 
        <Animatable.View animation="fadeInUp" style={styles.containerForm}>
        <Text style={styles.title}>E-mail</Text>
        <TextInput
        placeholder="E-mail"
        style={styles.input}/>
 
        <Text style={styles.title}>Password </Text>
        <TextInput 
        placeholder="Password"
        style={styles.input}/>
 
        <TouchableOpacity style={styles.button} onPress={() => callGetUsersList()}>
        <Text style={styles.buttonText}>Enter</Text>
        </TouchableOpacity>
 
         <TouchableOpacity style={styles.buttonRegister} onPress={ () => navigation.navigate('Cadastro')}>
        <Text style={styles.registerText} >Create account</Text>
        </TouchableOpacity>
 
        </Animatable.View>
      </ImageBackground>
      </View>
    );
  }
 
  const styles = StyleSheet.create({
    container:{
      flex:1,
    },
    containerHeader:{
      marginTop: '14%',
      marginBottom: '8%',
      paddingStart: '5%',
    },
    message:{
      fontSize: 28,
      fontWeight: 'bold',
      color: '#fff'
    },
    containerForm:{
      backgroundColor: 'rgba(255,255,255,0.8)',
      flex: 1,
      borderTopLeftRadius: 25,
      borderTopRightRadius: 25,
      paddingStart: '5%',
      paddingEnd: '5%',
    },
    title:{
      fontSize: 20,
      marginTop: 28,
    },
    input:{
      borderBottomWidth: 1,
      height: 40,
      marginBottom: 12,
      fontSize:16,
    },
    button:{
      backgroundColor: '#1E90FF',
      borderRadius: 4,
      paddingVertical: 8,
      width: '100%',
      marginTop: 14,
      justifyContent: 'center',
      alignItems: 'center',
 
    },
    buttonText:{
      color: '#fff',
      fontSize: 18,
      fontWeight: 'bold',
    },
    buttonRegister:{
      marginTop: 14,
      alignSelf: 'center',
    },
    registerText:{
      color: '#a1a1a1',
    }
  });
 

