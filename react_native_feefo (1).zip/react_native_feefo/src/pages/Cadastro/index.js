import { Text, View, StyleSheet, TextInput, TouchableOpacity, ImageBackground, FlatList } from 'react-native'
import React, {useState} from 'react'
import { Ionicons } from '@expo/vector-icons'
import axios from 'axios'

import * as Animatable from 'react-native-animatable'
import { useNavigation } from '@react-navigation/native'

export default function Cadastro() {
  const navigation = useNavigation();

     const callGetUsersList = () => {
       axios.get('https://crudcrud.com/api/4453925975e44e6ca49f93d94f22caf0/cadastro')
       .then(response => {
         console.log("Response:", response?.data);
       })
       .catch(error => {
         console.log("Error". error);
       });
     } 

     const callAddUsers = () =>{
       if(nome === '' || email === '' || senha === ''){
         alert("Fill all fields!")
         return;
       }
       let params = {nome: {nome}, email: {email}, senha:{senha}}
        axios.post('https://crudcrud.com/api/4453925975e44e6ca49f93d94f22caf0/cadastro',
        params,
        )
       .then(response => {
         navigation.navigate('Welcome');
       })
       .catch(error => {
         console.log("Error". error);
       });
     }
  
  const url ='https://crudcrud.com/api/4453925975e44e6ca49f93d94f22caf0/cadastro'
  
  const [input, setInput] = useState('');
  const [hidePass, setHidePass] = useState(true);
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

    
 
    return (
      <View style={styles.container}>
      <ImageBackground source={require('../../assets/fundoapplogin.png')} resizeMode="cover" style={{width: '100%', height:'100%'}}>
        <Animatable.View animation='fadeInLeft' delay={500} style={styles.containerHeader}>
          <Text style={styles.message}>Sign Up</Text>
        </Animatable.View>

         <Animatable.View animation="fadeInUp" style={styles.containerForm}>
        <Text style={styles.title}>Name</Text>
        <TextInput 
        value={nome}
        onChangeText={setNome}
        placeholder="Complete name"
        style={styles.input}/>

        <Text style={styles.title}>E-mail</Text>
        <TextInput
        value={email}
        onChangeText={setEmail}
        placeholder="E-mail"
        style={styles.input}/>
       
       <Text style={styles.title}>Password </Text>
        <View style={styles.inputArea}>
        <TextInput 
        value={senha}
        onChangeText={setSenha}
        placeholder="Password"
        style={styles.input}
        
        secureTextEntry={hidePass}
        />
         <TouchableOpacity style={styles.icon} onPress={ () => setHidePass(!hidePass) }>
         { hidePass ?
         <Ionicons name="eye" color="#000" size={25}/>
         :
         <Ionicons name="eye-off" color="#000" size={25}/>
         }
        
        </TouchableOpacity>
      </View>

        <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText} onPress={() => callAddUsers()} >Entrar</Text>
        </TouchableOpacity>


        </Animatable.View>
      </ImageBackground>
      </View>
    );
  }

  const styles = StyleSheet.create({
    container:{
      flex:1,
    },
    inputArea:{
      flexDirection: 'row',
      width: '90%',
      alignItems: 'center',
      borderRadius: 5,
    },
    containerHeader:{
      marginTop: '14%',
      marginBottom: '8%',
      paddingStart: '5%',
    },
    message:{
      fontSize: 28,
      fontWeight: 'bold',
      color: '#fff'
    },
    containerForm:{
      backgroundColor: 'rgba(255,255,255,0.8)',
      flex: 1,
      borderTopLeftRadius: 25,
      borderTopRightRadius: 25,
      paddingStart: '5%',
      paddingEnd: '5%',
    },
    title:{
      fontSize: 18,
      marginTop: 28,
    },
    input:{
      width: '85%',
      height: 50,
      marginBottom: 12,
      fontSize:18,
      borderBottomWidth: 1,
      padding: 8,
    },
    icon:{
      width: '15%',
      height: 50,
      justifyContent: 'center',
      alignItems: 'center',
      
    },
    button:{
      backgroundColor: '#1E90FF',
      borderRadius: 4,
      paddingVertical: 8,
      width: '100%',
      marginTop: 14,
      justifyContent: 'center',
      alignItems: 'center',

    },
    buttonText:{
      color: '#fff',
      fontSize: 18,
      fontWeight: 'bold',
    },
    buttonRegister:{
      marginTop: 14,
      alignSelf: 'center',
    },
    registerText:{
      color: '#a1a1a1',
    }
  })